const DatabaseService = require('./src/database.js');

(async () => {
  const db = new DatabaseService();
  await db.connect();
  
  // Get total records
  const totalResult = await db.executeQuery('SELECT COUNT(*) as total FROM CDW_push_arn_cleanup_results_staging');
  console.log('Total records:', totalResult.recordset[0].total);
  
  // Get records by run_id
  const runResult = await db.executeQuery(`
    SELECT run_id, COUNT(*) as count, MIN(batch_id) as min_batch, MAX(batch_id) as max_batch, MAX(id) as max_id
    FROM CDW_push_arn_cleanup_results_staging 
    GROUP BY run_id 
    ORDER BY MAX(id) DESC
  `);
  console.log('\nRecords by run:');
  runResult.recordset.forEach(r => console.log(`${r.run_id}: ${r.count} records, batches ${r.min_batch}-${r.max_batch}, max_id: ${r.max_id}`));
  
  // Get last few records
  const lastResult = await db.executeQuery(`
    SELECT TOP 10 id, run_id, batch_id, arn 
    FROM CDW_push_arn_cleanup_results_staging 
    ORDER BY id DESC
  `);
  console.log('\nLast 10 records:');
  lastResult.recordset.forEach(r => console.log(`ID: ${r.id}, Run: ${r.run_id}, Batch: ${r.batch_id}, ARN: ${r.arn.substring(0, 50)}...`));
  
  await db.disconnect();
})().catch(console.error);