const sql = require('mssql');
require('dotenv').config({ path: '.env.production' });

async function testProductionDB() {
    console.log('Testing Production Database Connection...');
    console.log('DB_SERVER:', process.env.DB_SERVER);
    console.log('DB_DATABASE:', process.env.DB_DATABASE);
    console.log('DB_PORT:', process.env.DB_PORT);
    console.log('DB_USER:', process.env.DB_USER);
    console.log('DB_ENCRYPT:', process.env.DB_ENCRYPT);
    console.log('DB_TRUST_SERVER_CERTIFICATE:', process.env.DB_TRUST_SERVER_CERTIFICATE);
    
    const config = {
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        server: process.env.DB_SERVER,
        database: process.env.DB_DATABASE,
        port: parseInt(process.env.DB_PORT) || 1433,
        options: {
            encrypt: process.env.DB_ENCRYPT === 'true',
            trustServerCertificate: process.env.DB_TRUST_SERVER_CERTIFICATE === 'true',
            enableArithAbort: true,
            connectTimeout: 30000,
            requestTimeout: 30000
        }
    };
    
    console.log('\nAttempting connection with config:');
    console.log(JSON.stringify({...config, password: '***'}, null, 2));
    
    try {
        const pool = new sql.ConnectionPool(config);
        await pool.connect();
        console.log('\n✅ Successfully connected to production database!');
        
        // Test a simple query
        const result = await pool.request().query('SELECT @@VERSION as version');
        console.log('\n📊 Database Version:', result.recordset[0].version);
        
        // Check if source table exists
        const tableCheck = await pool.request()
            .input('tableName', sql.NVarChar, process.env.SOURCE_TABLE_NAME)
            .query(`
                SELECT COUNT(*) as table_exists 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_NAME = @tableName
            `);
        
        if (tableCheck.recordset[0].table_exists > 0) {
            console.log(`✅ Source table '${process.env.SOURCE_TABLE_NAME}' exists`);
            
            // Check column exists
            const columnCheck = await pool.request()
                .input('tableName', sql.NVarChar, process.env.SOURCE_TABLE_NAME)
                .input('columnName', sql.NVarChar, process.env.SOURCE_ARN_COLUMN)
                .query(`
                    SELECT COUNT(*) as column_exists
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_NAME = @tableName AND COLUMN_NAME = @columnName
                `);
            
            if (columnCheck.recordset[0].column_exists > 0) {
                console.log(`✅ Column '${process.env.SOURCE_ARN_COLUMN}' exists in source table`);
                
                // Check for records
                const recordCount = await pool.request()
                    .query(`SELECT COUNT(*) as total_records FROM ${process.env.SOURCE_TABLE_NAME} WHERE ${process.env.SOURCE_ARN_COLUMN} IS NOT NULL`);
                
                console.log(`📊 Total records with ARNs: ${recordCount.recordset[0].total_records}`);
            } else {
                console.log(`❌ Column '${process.env.SOURCE_ARN_COLUMN}' does NOT exist in source table`);
            }
        } else {
            console.log(`❌ Source table '${process.env.SOURCE_TABLE_NAME}' does NOT exist`);
        }
        
        await pool.close();
        console.log('\n✅ Database connection test completed successfully!');
        
    } catch (error) {
        console.error('\n❌ Database connection failed:');
        console.error('Error Code:', error.code);
        console.error('Error Message:', error.message);
        
        if (error.code === 'ELOGIN') {
            console.log('\n🔍 Login failed - check username/password');
        } else if (error.code === 'ECONNREFUSED') {
            console.log('\n🔍 Connection refused - check server/port');
        } else if (error.code === 'ETIMEOUT') {
            console.log('\n🔍 Connection timeout - check network/firewall');
        }
        
        process.exit(1);
    }
}

testProductionDB().catch(console.error);