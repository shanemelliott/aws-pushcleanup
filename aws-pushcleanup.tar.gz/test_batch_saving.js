const Database = require('./src/database');
const { config } = require('./src/config');

async function testBatchSaving() {
  const db = new Database();
  try {
    await db.connect();
    console.log('Connected to database successfully');
    
    // Get current record count
    const beforeResult = await db.pool.request()
      .query(`SELECT COUNT(*) as total FROM ${config.app.resultsTableName}`);
    console.log(`Records before: ${beforeResult.recordset[0].total}`);
    
    // Simulate batch saving like the real application
    const testResults = [];
    for (let i = 1; i <= 10; i++) {
      testResults.push({
        runId: 'run-test-batch-save',
        batchId: 999,
        originalId: 9999900 + i,
        arn: `arn:test:batch:save:${i}`,
        status: i % 2 === 0 ? 'ENABLED' : 'DISABLED',
        statusReason: 'Test batch saving',
        errorMessage: null,
        metadata: { test: true, iteration: i }
      });
    }
    
    console.log('Saving test batch...');
    await db.batchSaveArnResults(testResults);
    console.log('Batch save completed');
    
    // Check record count after
    const afterResult = await db.pool.request()
      .query(`SELECT COUNT(*) as total FROM ${config.app.resultsTableName}`);
    console.log(`Records after: ${afterResult.recordset[0].total}`);
    
    // Verify the test records
    const testRecords = await db.pool.request()
      .query(`SELECT * FROM ${config.app.resultsTableName} WHERE run_id = 'run-test-batch-save' ORDER BY original_id`);
    console.log(`Test records found: ${testRecords.recordset.length}`);
    testRecords.recordset.forEach((record, index) => {
      console.log(`  ${index + 1}. ID: ${record.original_id}, Status: ${record.status}, ARN: ${record.arn}`);
    });
    
    // Clean up test records
    await db.pool.request()
      .query(`DELETE FROM ${config.app.resultsTableName} WHERE run_id = 'run-test-batch-save'`);
    console.log('Test records cleaned up');
    
  } catch (error) {
    console.error('Test error:', error.message);
    console.error('Stack:', error.stack);
  } finally {
    await db.disconnect();
  }
}

testBatchSaving();