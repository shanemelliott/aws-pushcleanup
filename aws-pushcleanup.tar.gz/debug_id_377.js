const Database = require('./src/database');
const { config } = require('./src/config');

(async () => {
  const db = new Database();
  try {
    await db.connect();
    console.log('Checking records around ID 377...');
    
    // Check what records exist around ID 377
    const result = await db.pool.request()
      .query(`SELECT TOP 10 id, targetArn FROM smsMobileClient WHERE id >= 377 ORDER BY id`);
    console.log('Records starting from ID 377:');
    result.recordset.forEach((row, i) => {
      console.log(`  ${i+1}. ID: ${row.id}, ARN: ${row.targetArn?.substring(0, 50)}...`);
    });
    
    // Check total count from ID 377
    const countResult = await db.pool.request()
      .query(`SELECT COUNT(*) as total FROM smsMobileClient WHERE id > 377`);
    console.log(`\nTotal records after ID 377: ${countResult.recordset[0].total}`);
    
    // Check if there are any NULL or problematic ARNs
    const nullArns = await db.pool.request()
      .query(`SELECT COUNT(*) as nullCount FROM smsMobileClient WHERE id > 377 AND (targetArn IS NULL OR targetArn = '')`);
    console.log(`NULL/empty ARNs after ID 377: ${nullArns.recordset[0].nullCount}`);
    
    await db.disconnect();
  } catch (error) {
    console.error('Error:', error.message);
    console.error('Stack:', error.stack);
  }
})();