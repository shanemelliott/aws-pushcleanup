const DatabaseService = require('./src/database.js');

(async () => {
  const db = new DatabaseService();
  await db.connect();
  
  console.log('Before deletion:');
  const beforeResult = await db.executeQuery(`
    SELECT run_id, COUNT(*) as count, MIN(batch_id) as min_batch, MAX(batch_id) as max_batch, MAX(id) as max_id
    FROM CDW_push_arn_cleanup_results_staging 
    WHERE run_id = 'run-2025-10-07T15-26-59-ygye'
    GROUP BY run_id
  `);
  beforeResult.recordset.forEach(r => console.log(`${r.run_id}: ${r.count} records, batches ${r.min_batch}-${r.max_batch}, max_id: ${r.max_id}`));
  
  // Delete the last 3 batches (53, 54, 55) to simulate interruption after batch 52
  console.log('\nDeleting batches 53, 54, and 55 to simulate interruption...');
  const deleteResult = await db.executeQuery(`
    DELETE FROM CDW_push_arn_cleanup_results_staging 
    WHERE run_id = 'run-2025-10-07T15-26-59-ygye' 
    AND batch_id IN (53, 54, 55)
  `);
  console.log(`Deleted ${deleteResult.rowsAffected[0]} records`);
  
  console.log('\nAfter deletion:');
  const afterResult = await db.executeQuery(`
    SELECT run_id, COUNT(*) as count, MIN(batch_id) as min_batch, MAX(batch_id) as max_batch, MAX(id) as max_id
    FROM CDW_push_arn_cleanup_results_staging 
    WHERE run_id = 'run-2025-10-07T15-26-59-ygye'
    GROUP BY run_id
  `);
  afterResult.recordset.forEach(r => console.log(`${r.run_id}: ${r.count} records, batches ${r.min_batch}-${r.max_batch}, max_id: ${r.max_id}`));
  
  // Show what records are missing now
  const missingResult = await db.executeQuery(`
    SELECT DISTINCT batch_id 
    FROM CDW_push_arn_cleanup_results_staging 
    WHERE run_id = 'run-2025-10-07T15-26-59-ygye'
    ORDER BY batch_id DESC
  `);
  console.log('\nRemaining batches:', missingResult.recordset.map(r => r.batch_id).join(', '));
  
  await db.disconnect();
  console.log('\n✅ Simulation setup complete! The script should now think it stopped after batch 52.');
})().catch(console.error);